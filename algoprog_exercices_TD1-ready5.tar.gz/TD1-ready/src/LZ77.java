// Ces squelettes sont à compléter et sont là uniquement pour prévenir des
// erreurs de compilation.
class Element {
  Element (Occurrence e, int s) {}
}

class Occurrence {
  Occurrence (int retour, int taille) {}
}
